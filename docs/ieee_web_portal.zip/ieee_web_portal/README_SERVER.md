# IEEE 下载网页服务（服务器版）

这个项目把现有 `ieee-download` 命令包装成一个小型网页：

- 输入论文标题、IEEE article number 或 document URL；
- 单线程排队下载；
- 显示日志与状态；
- 下载完成后从网页取回 PDF；
- 登录过期时，通过 noVNC 在服务器上的真实 Chromium 中手动完成机构登录。

## 重要边界

只用于你本人或所在机构依法有权访问的论文。不要绕过验证码、访问控制或下载限制；遇到 403、429、验证码或机构告警时停止。不要公开暴露 `ieee_profile/`、`ieee_auth.json`、Cookie、noVNC 或下载目录。

## 推荐架构

```text
浏览器
  │ SSH 隧道或 HTTPS/VPN
  ▼
FastAPI 网页（127.0.0.1:8092）
  │ 单任务队列
  ▼
现有 ieee-download
  │ DISPLAY=:99
  ▼
Xvfb + Chromium
  │
  └─ noVNC（仅 127.0.0.1:6080，供管理员人工登录）
```

不要启动多个 Uvicorn worker，也不要同时运行多个下载进程：它们会争用同一个 Playwright Profile。

## 一、服务器前提

假设：

- Ubuntu 22.04/24.04；
- 现有工具将放在 `/data/ieee_title_downloader`；
- 本网页项目放在 `/data/ieee_web_portal`；
- 服务运行用户示例为 `paperbot`；
- 服务器能通过学校正式允许的方式获得机构访问权限。

如果服务器公网 IP 无法取得机构权限，应改用校园服务器、学校正式 VPN/EZproxy，或让本地机器作为下载代理。不要把本地 Cookie/Profile 直接复制到云服务器。

## 二、安装系统组件

```bash
sudo apt update
sudo apt install -y \
  python3 python3-venv python3-pip \
  xvfb fluxbox x11vnc novnc websockify \
  nginx unzip
```

在现有 IEEE 工具环境中安装 Playwright 浏览器依赖：

```bash
cd /data/ieee_title_downloader
.venv/bin/playwright install --with-deps chromium
```

如果你的现有环境固定使用 Playwright 1.48：

```bash
.venv/bin/playwright install chromium
sudo .venv/bin/playwright install-deps chromium
```

## 三、安装网页项目

```bash
cd /data/ieee_web_portal
python3 -m venv .venv
.venv/bin/pip install --upgrade pip
.venv/bin/pip install -r requirements.txt
chmod +x start_web.sh
```

先手动测试虚拟桌面：

```bash
Xvfb :99 -screen 0 1440x900x24 -ac -nolisten tcp &
DISPLAY=:99 fluxbox &
x11vnc -display :99 -localhost -forever -shared -nopw -rfbport 5900 &
websockify --web=/usr/share/novnc/ 127.0.0.1:6080 127.0.0.1:5900 &
```

设置环境并启动网页：

```bash
export DISPLAY=:99
export IEEE_TOOL_DIR=/data/ieee_title_downloader
export IEEE_WEB_DATA=/data/ieee_web_data
export IEEE_WEB_USER=paper
export IEEE_WEB_PASSWORD='换成至少20位随机密码'

./start_web.sh
```

本地电脑建立 SSH 隧道：

```bash
ssh \
  -L 8092:127.0.0.1:8092 \
  -L 6080:127.0.0.1:6080 \
  用户名@服务器地址
```

浏览器打开：

```text
http://127.0.0.1:8092
```

需要机构登录时：

1. 网页点击“启动登录浏览器”；
2. 打开 `http://127.0.0.1:6080/vnc.html?autoconnect=true&resize=scale`；
3. 在 noVNC 的 Chromium 中完成机构登录，并确认一篇 PDF 能打开；
4. 回到网页点击“我已完成登录，保存状态”；
5. 重新提交失败的任务。

## 四、配置 systemd

把模板替换后复制到 `/etc/systemd/system/`。示例：

```bash
cd /data/ieee_web_portal

USER_NAME=paperbot
APP_DIR=/data/ieee_web_portal
TOOL_DIR=/data/ieee_title_downloader
DATA_DIR=/data/ieee_web_data
WEB_USER=paper
WEB_PASSWORD="$(openssl rand -base64 24 | tr -d '\n')"

echo "网页用户名：$WEB_USER"
echo "网页密码：$WEB_PASSWORD"
```

生成单位文件：

```bash
sed "s|__USER__|$USER_NAME|g" systemd/ieee-xvfb.service \
  | sudo tee /etc/systemd/system/ieee-xvfb.service >/dev/null

sed "s|__USER__|$USER_NAME|g" systemd/ieee-fluxbox.service \
  | sudo tee /etc/systemd/system/ieee-fluxbox.service >/dev/null

sed "s|__USER__|$USER_NAME|g" systemd/ieee-x11vnc.service \
  | sudo tee /etc/systemd/system/ieee-x11vnc.service >/dev/null

sed "s|__USER__|$USER_NAME|g" systemd/ieee-novnc.service \
  | sudo tee /etc/systemd/system/ieee-novnc.service >/dev/null

sed \
  -e "s|__USER__|$USER_NAME|g" \
  -e "s|__APP_DIR__|$APP_DIR|g" \
  -e "s|__TOOL_DIR__|$TOOL_DIR|g" \
  -e "s|__DATA_DIR__|$DATA_DIR|g" \
  -e "s|__WEB_USER__|$WEB_USER|g" \
  -e "s|__WEB_PASSWORD__|$WEB_PASSWORD|g" \
  systemd/ieee-web.service \
  | sudo tee /etc/systemd/system/ieee-web.service >/dev/null
```

注意：密码如果含有 `%`、引号等特殊字符，直接写进 systemd 文件可能需要转义。正式部署更建议用权限为 `600` 的 `EnvironmentFile`。

启用服务：

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now \
  ieee-xvfb \
  ieee-fluxbox \
  ieee-x11vnc \
  ieee-novnc \
  ieee-web
```

检查：

```bash
systemctl --no-pager --full status ieee-web
journalctl -u ieee-web -n 100 --no-pager
ss -lntp | grep -E '8092|6080|5900'
```

这些端口应只监听 `127.0.0.1`，不要直接开放 noVNC/VNC 到公网。

## 五、通过 Nginx 对外提供网页（可选）

先用 SSH 隧道跑通。团队长期使用时，再把网页放到单位 VPN、Tailscale 或带 HTTPS 的 Nginx 后面。

复制并修改：

```bash
sudo cp nginx/ieee-web.conf.example \
  /etc/nginx/sites-available/ieee-web

sudoedit /etc/nginx/sites-available/ieee-web

sudo ln -s /etc/nginx/sites-available/ieee-web \
  /etc/nginx/sites-enabled/ieee-web

sudo nginx -t
sudo systemctl reload nginx
```

FastAPI 自身的 Basic Auth 只是最低保护；公网部署必须使用 HTTPS，并最好增加防火墙、VPN/SSO、访问日志和速率限制。noVNC 仍建议只通过 SSH 隧道访问。

## 六、常见状态

- `queued`：等待前面的任务。
- `running`：正在调用 `ieee-download`。
- `success`：网页出现“下载 PDF”。
- `needs_login`：机构会话过期；完成 noVNC 登录后重新提交。
- `failed`：查看任务日志。遇到 403、429 或验证码时停止，不要重试轰炸。

## 七、验证

```bash
curl -I http://127.0.0.1:8092
journalctl -u ieee-web -f
```

网页提交：

```text
10229085
```

下载成功后，PDF 仍保存在：

```text
/data/ieee_title_downloader/downloads/
```
