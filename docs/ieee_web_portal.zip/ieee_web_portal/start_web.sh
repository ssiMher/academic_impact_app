#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec "$ROOT/.venv/bin/uvicorn" web_app:app \
  --app-dir "$ROOT" \
  --host 127.0.0.1 \
  --port "${IEEE_WEB_PORT:-8092}" \
  --workers 1
