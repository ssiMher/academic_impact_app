#!/usr/bin/env python3
from __future__ import annotations

import html
import os
import re
import secrets
import sqlite3
import subprocess
import threading
import time
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from fastapi import Depends, FastAPI, Form, HTTPException, status
from fastapi.responses import FileResponse, HTMLResponse, RedirectResponse
from fastapi.security import HTTPBasic, HTTPBasicCredentials


TOOL_DIR = Path(
    os.environ.get("IEEE_TOOL_DIR", "/data/ieee_title_downloader")
).resolve()
TOOL = (TOOL_DIR / "ieee-download").resolve()
DOWNLOAD_DIR = Path(
    os.environ.get("IEEE_DOWNLOAD_DIR", str(TOOL_DIR / "downloads"))
).resolve()
DATA_DIR = Path(
    os.environ.get("IEEE_WEB_DATA", "/data/ieee_web_data")
).resolve()
DB_PATH = DATA_DIR / "jobs.sqlite3"
LOGIN_LOG = DATA_DIR / "login.log"

DISPLAY_VALUE = os.environ.get("DISPLAY", ":99")
NOVNC_URL = os.environ.get(
    "IEEE_NOVNC_URL",
    "http://127.0.0.1:6080/vnc.html?autoconnect=true&resize=scale",
)
WEB_USER = os.environ.get("IEEE_WEB_USER", "paper")
WEB_PASSWORD = os.environ.get("IEEE_WEB_PASSWORD", "")
JOB_TIMEOUT_SECONDS = int(os.environ.get("IEEE_JOB_TIMEOUT_SECONDS", "900"))

DATA_DIR.mkdir(parents=True, exist_ok=True)
DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)

security = HTTPBasic()
stop_event = threading.Event()
worker_thread: Optional[threading.Thread] = None
login_lock = threading.Lock()
login_process: Optional[subprocess.Popen] = None
login_log_handle = None


def now_iso() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


def connect_db() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    with connect_db() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS jobs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                query TEXT NOT NULL,
                status TEXT NOT NULL,
                created_at TEXT NOT NULL,
                started_at TEXT,
                finished_at TEXT,
                output TEXT NOT NULL DEFAULT '',
                file_path TEXT
            )
            """
        )
        # 服务重启时，将未完成任务重新放回队列。
        conn.execute(
            """
            UPDATE jobs
            SET status='queued', started_at=NULL
            WHERE status='running'
            """
        )


def require_user(
    credentials: HTTPBasicCredentials = Depends(security),
) -> str:
    if not WEB_PASSWORD:
        raise HTTPException(
            status_code=500,
            detail="服务器未设置 IEEE_WEB_PASSWORD",
        )

    username_ok = secrets.compare_digest(
        credentials.username.encode("utf-8"),
        WEB_USER.encode("utf-8"),
    )
    password_ok = secrets.compare_digest(
        credentials.password.encode("utf-8"),
        WEB_PASSWORD.encode("utf-8"),
    )

    if not (username_ok and password_ok):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="用户名或密码错误",
            headers={"WWW-Authenticate": "Basic"},
        )
    return credentials.username


def safe_file_from_output(output: str) -> Optional[Path]:
    patterns = (
        r"\[成功\]\s+(.+?\.pdf)\s*$",
        r"\[跳过\]\s+已存在：\s*(.+?\.pdf)\s*$",
    )
    for line in output.splitlines():
        for pattern in patterns:
            match = re.search(pattern, line)
            if not match:
                continue
            candidate = Path(match.group(1).strip())
            if not candidate.is_absolute():
                candidate = (TOOL_DIR / candidate).resolve()
            else:
                candidate = candidate.resolve()
            try:
                candidate.relative_to(DOWNLOAD_DIR)
            except ValueError:
                continue
            if candidate.is_file():
                return candidate
    return None


def newest_pdf_since(start_time: float) -> Optional[Path]:
    candidates = []
    for path in DOWNLOAD_DIR.glob("*.pdf"):
        try:
            if path.stat().st_mtime >= start_time - 2:
                candidates.append(path)
        except OSError:
            continue
    if not candidates:
        return None
    return max(candidates, key=lambda p: p.stat().st_mtime).resolve()


def claim_next_job() -> Optional[sqlite3.Row]:
    with connect_db() as conn:
        conn.execute("BEGIN IMMEDIATE")
        row = conn.execute(
            """
            SELECT * FROM jobs
            WHERE status='queued'
            ORDER BY id
            LIMIT 1
            """
        ).fetchone()
        if row is None:
            conn.commit()
            return None
        conn.execute(
            """
            UPDATE jobs
            SET status='running', started_at=?
            WHERE id=?
            """,
            (now_iso(), row["id"]),
        )
        conn.commit()
        return row


def update_job(
    job_id: int,
    *,
    job_status: str,
    output: str,
    file_path: Optional[Path] = None,
) -> None:
    with connect_db() as conn:
        conn.execute(
            """
            UPDATE jobs
            SET status=?, finished_at=?, output=?, file_path=?
            WHERE id=?
            """,
            (
                job_status,
                now_iso(),
                output[-100_000:],
                str(file_path) if file_path else None,
                job_id,
            ),
        )


def run_job(job: sqlite3.Row) -> None:
    query = str(job["query"])
    started = time.time()
    env = os.environ.copy()
    env["DISPLAY"] = DISPLAY_VALUE
    env["PYTHONUNBUFFERED"] = "1"

    command = [str(TOOL), "-y", query]

    try:
        completed = subprocess.run(
            command,
            cwd=str(TOOL_DIR),
            env=env,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=JOB_TIMEOUT_SECONDS,
            check=False,
        )
        output = completed.stdout or ""
    except subprocess.TimeoutExpired as exc:
        output = (exc.stdout or "") + "\n任务超时。"
        update_job(
            int(job["id"]),
            job_status="failed",
            output=output,
        )
        return
    except Exception as exc:
        update_job(
            int(job["id"]),
            job_status="failed",
            output=f"{type(exc).__name__}: {exc}",
        )
        return

    pdf_path = safe_file_from_output(output) or newest_pdf_since(started)

    if completed.returncode == 0 and pdf_path is not None:
        update_job(
            int(job["id"]),
            job_status="success",
            output=output,
            file_path=pdf_path,
        )
        return

    lower = output.lower()
    needs_login_markers = (
        "[需要登录]",
        "institutional sign in",
        "eof when reading a line",
        "机构登录仍未生效",
        "当前 ieee 机构会话已经失效",
    )
    if any(marker.lower() in lower for marker in needs_login_markers):
        final_status = "needs_login"
    else:
        final_status = "failed"

    update_job(
        int(job["id"]),
        job_status=final_status,
        output=output,
    )


def worker_loop() -> None:
    while not stop_event.is_set():
        job = claim_next_job()
        if job is None:
            stop_event.wait(1.0)
            continue
        run_job(job)


def start_worker() -> None:
    global worker_thread
    worker_thread = threading.Thread(
        target=worker_loop,
        name="ieee-download-worker",
        daemon=True,
    )
    worker_thread.start()


@asynccontextmanager
async def lifespan(_: FastAPI):
    init_db()
    start_worker()
    yield
    stop_event.set()
    if worker_thread:
        worker_thread.join(timeout=5)


app = FastAPI(
    title="IEEE Paper Downloader",
    docs_url=None,
    redoc_url=None,
    lifespan=lifespan,
)


def render_page(message: str = "") -> str:
    with connect_db() as conn:
        jobs = conn.execute(
            "SELECT * FROM jobs ORDER BY id DESC LIMIT 50"
        ).fetchall()

    rows = []
    for job in jobs:
        job_id = int(job["id"])
        state = html.escape(str(job["status"]))
        query = html.escape(str(job["query"]))
        created = html.escape(str(job["created_at"]))
        action = ""
        if job["status"] == "success" and job["file_path"]:
            action = (
                f'<a class="button" href="/jobs/{job_id}/download">'
                "下载 PDF</a>"
            )
        elif job["status"] == "needs_login":
            action = '<span class="warn">请先完成机构登录后重新提交</span>'

        output = html.escape(str(job["output"] or "")[-5000:])
        rows.append(
            f"""
            <tr>
              <td>{job_id}</td>
              <td>{query}</td>
              <td><strong>{state}</strong></td>
              <td>{created}</td>
              <td>{action}</td>
            </tr>
            <tr class="log-row">
              <td colspan="5"><details><summary>日志</summary>
              <pre>{output}</pre></details></td>
            </tr>
            """
        )

    login_state = login_status_text()
    message_html = (
        f'<div class="message">{html.escape(message)}</div>'
        if message
        else ""
    )

    return f"""<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta http-equiv="refresh" content="5">
<title>IEEE 论文下载</title>
<style>
body {{ font-family: system-ui, sans-serif; max-width: 1100px; margin: 30px auto;
       padding: 0 18px; background: #f6f7f9; color: #1f2937; }}
.card {{ background: white; border-radius: 12px; padding: 20px; margin-bottom: 18px;
         box-shadow: 0 2px 12px rgba(0,0,0,.07); }}
input[type=text] {{ width: min(760px, 95%); padding: 12px; font-size: 16px; }}
button,.button {{ display: inline-block; border: 0; border-radius: 8px; padding: 10px 16px;
                  background: #1769aa; color: white; text-decoration: none; cursor: pointer; }}
button.secondary {{ background: #4b5563; }}
table {{ width: 100%; border-collapse: collapse; }}
th,td {{ border-bottom: 1px solid #e5e7eb; padding: 10px; text-align: left; vertical-align: top; }}
pre {{ white-space: pre-wrap; max-height: 330px; overflow: auto; background: #111827;
       color: #e5e7eb; padding: 12px; border-radius: 8px; }}
.warn {{ color: #b45309; font-weight: 700; }}
.message {{ padding: 12px; background: #ecfeff; border: 1px solid #a5f3fc; margin-bottom: 12px; }}
.small {{ color: #6b7280; font-size: 14px; }}
.actions form {{ display: inline-block; margin-right: 8px; }}
</style>
</head>
<body>
<h1>IEEE 论文下载</h1>
{message_html}
<div class="card">
  <h2>提交任务</h2>
  <form method="post" action="/jobs">
    <input type="text" name="query" required
      placeholder="输入完整论文标题、IEEE article number 或 document URL">
    <button type="submit">加入下载队列</button>
  </form>
  <p class="small">任务严格串行执行，避免多个 Playwright 实例同时使用同一浏览器 Profile。</p>
</div>

<div class="card">
  <h2>机构登录</h2>
  <p>状态：<strong>{html.escape(login_state)}</strong></p>
  <p class="small">
    需要登录时：先建立 SSH 隧道，再打开
    <a href="{html.escape(NOVNC_URL)}" target="_blank">noVNC 登录桌面</a>。
  </p>
  <div class="actions">
    <form method="post" action="/login/start">
      <button type="submit" class="secondary">启动登录浏览器</button>
    </form>
    <form method="post" action="/login/finish">
      <button type="submit">我已完成登录，保存状态</button>
    </form>
    <form method="post" action="/login/cancel">
      <button type="submit" class="secondary">取消登录进程</button>
    </form>
  </div>
  <p><a href="/login/log">查看登录日志</a></p>
</div>

<div class="card">
  <h2>最近任务</h2>
  <table>
    <thead><tr><th>ID</th><th>查询</th><th>状态</th><th>创建时间</th><th>操作</th></tr></thead>
    <tbody>{''.join(rows) if rows else '<tr><td colspan="5">暂无任务</td></tr>'}</tbody>
  </table>
</div>
</body>
</html>"""


def login_status_text() -> str:
    with login_lock:
        if login_process is None:
            return "未运行"
        code = login_process.poll()
        if code is None:
            return "登录浏览器正在运行，等待人工操作"
        return f"登录进程已结束，退出码 {code}"


@app.get("/", response_class=HTMLResponse)
def index(_: str = Depends(require_user)):
    return HTMLResponse(render_page())


@app.post("/jobs")
def create_job(
    query: str = Form(...),
    _: str = Depends(require_user),
):
    query = query.strip()
    if not query or len(query) > 1000:
        raise HTTPException(status_code=400, detail="查询内容无效")

    with connect_db() as conn:
        conn.execute(
            """
            INSERT INTO jobs(query, status, created_at)
            VALUES (?, 'queued', ?)
            """,
            (query, now_iso()),
        )

    return RedirectResponse("/", status_code=303)


@app.get("/jobs/{job_id}/download")
def download_job(
    job_id: int,
    _: str = Depends(require_user),
):
    with connect_db() as conn:
        job = conn.execute(
            "SELECT * FROM jobs WHERE id=?",
            (job_id,),
        ).fetchone()

    if job is None or job["status"] != "success" or not job["file_path"]:
        raise HTTPException(status_code=404, detail="文件不存在")

    path = Path(str(job["file_path"])).resolve()
    try:
        path.relative_to(DOWNLOAD_DIR)
    except ValueError:
        raise HTTPException(status_code=403, detail="非法文件路径")
    if not path.is_file():
        raise HTTPException(status_code=404, detail="文件已不存在")

    return FileResponse(
        path=str(path),
        media_type="application/pdf",
        filename=path.name,
    )


@app.post("/login/start")
def start_login(_: str = Depends(require_user)):
    global login_process, login_log_handle

    with login_lock:
        if login_process is not None and login_process.poll() is None:
            return RedirectResponse(
                "/?message=登录进程已经在运行",
                status_code=303,
            )

        LOGIN_LOG.parent.mkdir(parents=True, exist_ok=True)
        login_log_handle = open(LOGIN_LOG, "a", encoding="utf-8")
        login_log_handle.write(
            f"\n\n===== login start {now_iso()} =====\n"
        )
        login_log_handle.flush()

        env = os.environ.copy()
        env["DISPLAY"] = DISPLAY_VALUE
        env["PYTHONUNBUFFERED"] = "1"

        login_process = subprocess.Popen(
            [str(TOOL), "--login"],
            cwd=str(TOOL_DIR),
            env=env,
            stdin=subprocess.PIPE,
            stdout=login_log_handle,
            stderr=subprocess.STDOUT,
            text=True,
        )

    return RedirectResponse(
        "/?message=登录浏览器已启动，请通过 noVNC 完成机构登录",
        status_code=303,
    )


@app.post("/login/finish")
def finish_login(_: str = Depends(require_user)):
    global login_process, login_log_handle

    with login_lock:
        if login_process is None or login_process.poll() is not None:
            return RedirectResponse(
                "/?message=当前没有等待保存的登录进程",
                status_code=303,
            )

        assert login_process.stdin is not None
        login_process.stdin.write("\n")
        login_process.stdin.flush()

        try:
            code = login_process.wait(timeout=45)
        except subprocess.TimeoutExpired:
            return RedirectResponse(
                "/?message=登录保存尚未结束，请稍后刷新",
                status_code=303,
            )

        if login_log_handle:
            login_log_handle.flush()
            login_log_handle.close()
            login_log_handle = None

    message = "登录状态已保存" if code == 0 else f"登录进程退出码为 {code}"
    return RedirectResponse(
        f"/?message={message}",
        status_code=303,
    )


@app.post("/login/cancel")
def cancel_login(_: str = Depends(require_user)):
    global login_process, login_log_handle

    with login_lock:
        if login_process is not None and login_process.poll() is None:
            login_process.terminate()
            try:
                login_process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                login_process.kill()
        if login_log_handle:
            login_log_handle.close()
            login_log_handle = None
        login_process = None

    return RedirectResponse(
        "/?message=登录进程已取消",
        status_code=303,
    )


@app.get("/login/log", response_class=HTMLResponse)
def login_log(_: str = Depends(require_user)):
    content = LOGIN_LOG.read_text(
        encoding="utf-8",
        errors="replace",
    ) if LOGIN_LOG.exists() else "暂无日志"
    return HTMLResponse(
        "<!doctype html><meta charset='utf-8'>"
        "<p><a href='/'>返回</a></p>"
        f"<pre>{html.escape(content[-100_000:])}</pre>"
    )
