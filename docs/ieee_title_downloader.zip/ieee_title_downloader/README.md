# IEEE 论文标题下载器

用途：使用一个持久化的 Playwright 浏览器会话，在你已获授权的 IEEE/学校机构访问范围内，根据论文标题、article number 或 IEEE document URL 下载 PDF。

## 1. 安装

```bash
cd ieee_title_downloader
chmod +x setup.sh ieee-download
./setup.sh
```

如果 Chromium 因缺少系统库无法启动：

```bash
sudo .venv/bin/playwright install-deps chromium
.venv/bin/playwright install chromium
```

## 2. 第一次登录

```bash
./ieee-download --login
```

在打开的专用浏览器中完成 IEEE/学校统一认证，并确认任意有权限的 PDF 能打开。登录状态保存在 `ieee_profile/`，不要上传或分享这个目录。

## 3. 按标题下载

```bash
./ieee-download "mmMIC: Multi-modal Speech Recognition based on mmWave Radar"
```

标题高度匹配时会自动选中；有歧义时会显示前 5 个候选供确认。

自动选择最高匹配：

```bash
./ieee-download -y "完整论文标题"
```

## 4. 按 article number 或 URL 下载

```bash
./ieee-download 10229085
```

```bash
./ieee-download "https://ieeexplore.ieee.org/document/10229085"
```

文件保存到：

```text
downloads/
```

## 5. 日常固定用法

可以把命令加入 PATH：

```bash
mkdir -p "$HOME/.local/bin"
ln -sf "$(pwd)/ieee-download" "$HOME/.local/bin/ieee-download"
echo 'export PATH="$HOME/.local/bin:$PATH"' >> "$HOME/.bashrc"
source "$HOME/.bashrc"
```

以后在任意目录执行：

```bash
ieee-download "论文完整标题"
```

## 注意

- 只下载你个人或所在机构依法有权访问的论文。
- 登录或人机验证由你在可见浏览器中手动完成，不要尝试绕过。
- 遇到 403、429 或权限页面应停止并检查登录/访问权限。
- 不要将 `ieee_profile/`、Cookie、令牌或复制的 cURL 提交到 Git 或发给他人。
- IEEE 页面结构变化后，标题搜索部分可能需要调整；article number 模式通常更稳定。
