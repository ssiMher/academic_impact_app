#!/usr/bin/env python3
from __future__ import annotations

import argparse
import re
import sys
import time
from difflib import SequenceMatcher
from pathlib import Path
from urllib.parse import quote, unquote

from playwright.sync_api import (
    BrowserContext,
    Page,
    Response,
    TimeoutError as PlaywrightTimeoutError,
    sync_playwright,
)

ROOT = Path(__file__).resolve().parent
PROFILE_DIR = ROOT / "ieee_profile"
DOWNLOAD_DIR = ROOT / "downloads"
DEFAULT_TIMEOUT_MS = 120_000


def normalize_title(text: str) -> str:
    text = unquote(text)
    text = text.casefold()
    text = re.sub(r"[\W_]+", " ", text, flags=re.UNICODE)
    return " ".join(text.split())


def similarity(a: str, b: str) -> float:
    return SequenceMatcher(None, normalize_title(a), normalize_title(b)).ratio()


def safe_filename(value: str) -> str:
    value = unquote(value).strip()
    value = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", value)
    value = re.sub(r"\s+", " ", value).strip(" .")
    return value or "paper"


def filename_from_response(
    response: Response,
    article_number: str,
    fallback_title: str,
) -> str:
    disposition = response.headers.get("content-disposition", "")
    match = re.search(
        r"""filename\*?=(?:UTF-8''|")?([^";]+)""",
        disposition,
        flags=re.IGNORECASE,
    )
    if match:
        name = safe_filename(match.group(1).rstrip('"'))
        if not name.lower().endswith(".pdf"):
            name += ".pdf"
        return f"{article_number}_{name}"

    name = safe_filename(fallback_title)
    if not name.lower().endswith(".pdf"):
        name += ".pdf"
    return f"{article_number}_{name}"


def is_complete_pdf(data: bytes) -> bool:
    return data.startswith(b"%PDF-") and b"%%EOF" in data[-16384:]


def create_context(playwright) -> BrowserContext:
    PROFILE_DIR.mkdir(parents=True, exist_ok=True)
    return playwright.chromium.launch_persistent_context(
        user_data_dir=str(PROFILE_DIR.resolve()),
        headless=False,
        accept_downloads=True,
        viewport={"width": 1440, "height": 900},
    )


def login_mode(context: BrowserContext) -> None:
    page = context.pages[0] if context.pages else context.new_page()
    page.goto(
        "https://ieeexplore.ieee.org/",
        wait_until="domcontentloaded",
        timeout=DEFAULT_TIMEOUT_MS,
    )
    print(
        "\n已打开专用 IEEE 浏览器。\n"
        "请在其中完成 IEEE/学校机构登录，并确认任意有权限的论文 PDF 能正常打开。\n"
        "完成后回到终端按 Enter。"
    )
    input()
    print(f"登录状态保存在：{PROFILE_DIR}")


def extract_candidates(page: Page, query_title: str) -> list[dict[str, object]]:
    # IEEE 页面结构可能变化，因此只依赖稳定的 /document/<arnumber> 链接。
    locator = page.locator('a[href*="/document/"]')
    try:
        locator.first.wait_for(state="attached", timeout=30_000)
    except PlaywrightTimeoutError:
        return []

    candidates: dict[str, dict[str, object]] = {}
    count = min(locator.count(), 300)

    for index in range(count):
        item = locator.nth(index)
        try:
            href = item.get_attribute("href") or ""
            match = re.search(r"/document/(\d+)", href)
            if not match:
                continue

            article_number = match.group(1)
            text = " ".join((item.inner_text(timeout=2_000) or "").split())

            # 某些链接文本是“PDF”“Abstract”等，尝试从父级卡片取文字。
            if len(text) < 12:
                try:
                    parent_text = " ".join(
                        (item.locator("xpath=ancestor::*[self::xpl-results-item or self::div][1]")
                         .inner_text(timeout=2_000) or "").split()
                    )
                    if parent_text:
                        text = parent_text
                except Exception:
                    pass

            if len(text) < 12:
                continue

            # 去掉常见操作文字，保留最可能的标题部分。
            text = re.sub(
                r"\b(PDF|Abstract|HTML|View Document|Full Text|Cited by \d+)\b",
                " ",
                text,
                flags=re.IGNORECASE,
            )
            text = " ".join(text.split())
            score = similarity(query_title, text)

            previous = candidates.get(article_number)
            if previous is None or score > float(previous["score"]):
                candidates[article_number] = {
                    "article_number": article_number,
                    "title": text,
                    "score": score,
                }
        except Exception:
            continue

    return sorted(
        candidates.values(),
        key=lambda item: float(item["score"]),
        reverse=True,
    )


def search_title(page: Page, title: str, auto_yes: bool) -> tuple[str, str]:
    query = f'"{title}"'
    search_url = (
        "https://ieeexplore.ieee.org/search/searchresult.jsp"
        f"?newsearch=true&queryText={quote(query)}"
    )
    print(f"[搜索] {title}")
    page.goto(
        search_url,
        wait_until="domcontentloaded",
        timeout=DEFAULT_TIMEOUT_MS,
    )
    page.wait_for_timeout(4_000)

    candidates = extract_candidates(page, title)
    if not candidates:
        print(
            "\n没有读取到搜索结果。请检查打开的浏览器：\n"
            "1. 是否需要登录；\n"
            "2. 是否出现人机验证；\n"
            "3. 搜索结果是否已正常显示。\n"
        )
        input("处理完成后按 Enter 重新读取搜索结果：")
        page.wait_for_timeout(2_000)
        candidates = extract_candidates(page, title)

    if not candidates:
        raise RuntimeError("仍未找到可识别的 IEEE 文档链接。")

    top = candidates[:5]
    print("\n候选论文：")
    for index, candidate in enumerate(top, start=1):
        print(
            f"  {index}. [{candidate['article_number']}] "
            f"相似度={float(candidate['score']):.3f}\n"
            f"     {candidate['title'][:240]}"
        )

    best = top[0]
    if auto_yes or float(best["score"]) >= 0.93:
        print(f"\n[选择] {best['article_number']}（最高匹配）")
        return str(best["article_number"]), str(best["title"])

    while True:
        choice = input("\n请输入候选序号（1-5），直接回车选择 1：").strip() or "1"
        if choice.isdigit() and 1 <= int(choice) <= len(top):
            selected = top[int(choice) - 1]
            return str(selected["article_number"]), str(selected["title"])
        print("输入无效。")


def capture_pdf_response(page: Page, article_number: str) -> Response:
    stamp_url = (
        "https://ieeexplore.ieee.org/stamp/stamp.jsp"
        f"?tp=&arnumber={article_number}"
    )

    def predicate(response: Response) -> bool:
        content_type = response.headers.get("content-type", "").lower()
        return (
            response.status == 200
            and "application/pdf" in content_type
            and (
                "stampPDF/getPDF.jsp" in response.url
                or article_number in response.url
            )
        )

    print(f"[下载] 打开 IEEE PDF 页面：{article_number}")
    with page.expect_response(predicate, timeout=DEFAULT_TIMEOUT_MS) as info:
        page.goto(
            stamp_url,
            wait_until="domcontentloaded",
            timeout=DEFAULT_TIMEOUT_MS,
        )

    response = info.value
    response.finished()
    return response


def download_article(
    context: BrowserContext,
    page: Page,
    article_number: str,
    title: str,
) -> Path:
    DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)

    existing = sorted(DOWNLOAD_DIR.glob(f"{article_number}_*.pdf"))
    if existing:
        print(f"[跳过] 已存在：{existing[0]}")
        return existing[0]

    for attempt in range(1, 3):
        try:
            response = capture_pdf_response(page, article_number)
            data = response.body()

            # 少数情况下浏览器可能只取到分段内容，再通过同一持久会话重取一次。
            if not is_complete_pdf(data):
                print("[提示] 首次响应可能不完整，正在用同一浏览器会话重新获取……")
                api_response = context.request.get(
                    response.url,
                    headers={
                        "Accept": "application/pdf,*/*",
                        "Referer": (
                            "https://ieeexplore.ieee.org/stamp/stamp.jsp"
                            f"?tp=&arnumber={article_number}"
                        ),
                    },
                    timeout=DEFAULT_TIMEOUT_MS,
                    fail_on_status_code=False,
                )
                if api_response.status == 200:
                    data = api_response.body()

            if not data.startswith(b"%PDF-"):
                raise RuntimeError("返回内容不是 PDF，可能是登录页或权限页面。")

            filename = filename_from_response(response, article_number, title)
            target = DOWNLOAD_DIR / filename
            target.write_bytes(data)

            size_mb = len(data) / 1024 / 1024
            print(f"[成功] {target}")
            print(f"[大小] {size_mb:.2f} MB")
            if b"%%EOF" not in data[-16384:]:
                print("[警告] 未在文件尾找到 %%EOF，请手动打开确认文件完整性。")
            return target

        except PlaywrightTimeoutError:
            screenshot = DOWNLOAD_DIR / f"{article_number}_timeout.png"
            page.screenshot(path=str(screenshot), full_page=True)
            if attempt == 1:
                print(
                    "\n没有捕获到 PDF 响应。请在浏览器中检查：\n"
                    "1. 是否需要重新登录；\n"
                    "2. 是否出现人机验证；\n"
                    "3. 当前机构是否有该论文访问权限。\n"
                    f"诊断截图：{screenshot}"
                )
                input("处理完成后按 Enter 重试：")
                continue
            raise RuntimeError("重试后仍未捕获到 PDF 响应。")

    raise RuntimeError("下载失败。")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="通过持久化浏览器会话搜索并下载有权限访问的 IEEE 论文。"
    )
    parser.add_argument(
        "query",
        nargs="?",
        help="论文完整标题、IEEE article number，或 IEEE document URL。",
    )
    parser.add_argument(
        "--login",
        action="store_true",
        help="只打开专用浏览器，手动完成 IEEE/学校机构登录。",
    )
    parser.add_argument(
        "-y",
        "--yes",
        action="store_true",
        help="搜索标题时自动选择最高匹配候选。",
    )
    return parser.parse_args()


def resolve_query(page: Page, query: str, auto_yes: bool) -> tuple[str, str]:
    query = query.strip()
    match = re.fullmatch(r"\d{6,12}", query)
    if match:
        return match.group(0), match.group(0)

    match = re.search(r"ieeexplore\.ieee\.org/document/(\d+)", query)
    if match:
        return match.group(1), match.group(1)

    return search_title(page, query, auto_yes)


def main() -> int:
    args = parse_args()
    if not args.login and not args.query:
        print(
            '用法：\n'
            '  python ieee_download.py --login\n'
            '  python ieee_download.py "完整论文标题"\n'
            '  python ieee_download.py 10229085\n'
            '  python ieee_download.py "https://ieeexplore.ieee.org/document/10229085"\n'
        )
        return 2

    with sync_playwright() as playwright:
        context = create_context(playwright)
        try:
            if args.login:
                login_mode(context)
                return 0

            page = context.pages[0] if context.pages else context.new_page()
            page.set_default_timeout(DEFAULT_TIMEOUT_MS)

            article_number, selected_title = resolve_query(
                page,
                args.query,
                args.yes,
            )
            download_article(
                context,
                page,
                article_number,
                selected_title,
            )
            time.sleep(1)
            return 0
        finally:
            context.close()


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("\n用户取消。", file=sys.stderr)
        raise SystemExit(130)
    except Exception as exc:
        print(f"\n[失败] {type(exc).__name__}: {exc}", file=sys.stderr)
        raise SystemExit(1)
